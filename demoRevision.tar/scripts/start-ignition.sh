#Start Service
/etc/init.d/ignition start